
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { motion } from "framer-motion";

export default function HomePage() {
  return (
    <div className="min-h-screen bg-black text-white">
      <header className="bg-gradient-to-r from-red-800 via-black to-cyan-700 p-6 shadow-xl text-white">
        <h1 className="text-4xl font-bold text-center">Talk of the Town</h1>
        <p className="text-center text-sm mt-2">Las Vegas' Premier 18+ Fully Nude Gentlemen's Club</p>
      </header>

      <main className="p-4 grid gap-6 max-w-5xl mx-auto text-white">
        <motion.div 
          className="text-center"
          initial={{ opacity: 0, y: 20 }} 
          animate={{ opacity: 1, y: 0 }} 
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-2xl font-semibold mb-2">Welcome to the Wild Side of Vegas</h2>
          <p className="text-base">
            Step into an electrifying night of entertainment at Talk of the Town. We're open late with jaw-dropping performances, private VIP experiences, and a fully stocked adult emporium shop.
          </p>
        </motion.div>

        <section className="grid md:grid-cols-2 gap-6">
          <Card className="bg-red-900/60 border-red-700 text-white">
            <CardContent className="p-4">
              <h3 className="text-xl font-bold mb-2">🔥 Attractions</h3>
              <ul className="list-disc list-inside space-y-1 text-sm">
                <li>Fully Nude Dancers</li>
                <li>Private VIP Lounge</li>
                <li>Live Themed Shows</li>
                <li>Adult Retail Emporium</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="bg-cyan-800 border-cyan-600 text-white">
            <CardContent className="p-4">
              <h3 className="text-xl font-bold mb-2">📍 Location</h3>
              <p className="text-sm mb-2">
                1238 Las Vegas Blvd S,<br/>Las Vegas, NV 89104
              </p>
              <Button variant="default" className="bg-cyan-600 hover:bg-cyan-700 text-white w-full">
                Get Directions
              </Button>
            </CardContent>
          </Card>
        </section>

        <section className="bg-red-950/50 p-6 rounded-2xl shadow-lg text-white">
          <h3 className="text-xl font-bold mb-4">💃 Work With Us</h3>
          <p className="mb-2 text-sm">Interested in becoming a dancer or staff member? Apply now through our secure online portal.</p>
          <Button variant="default" className="bg-cyan-600 hover:bg-cyan-700 w-full">
            Apply Now
          </Button>
        </section>
      </main>

      <footer className="bg-black border-t border-red-800 mt-10 p-4 text-center text-sm text-gray-400">
        &copy; {new Date().getFullYear()} Talk of the Town. All rights reserved. | 18+ Only
      </footer>
    </div>
  );
}
